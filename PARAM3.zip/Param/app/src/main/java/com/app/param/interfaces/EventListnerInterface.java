package com.app.param.interfaces;

public interface EventListnerInterface {
    void onItemClick(int position);
}
