package com.app.param.interfaces;

public interface TotalListnerInterface {
    void onItemView(int position);
    void onItemClick(int position);

}
